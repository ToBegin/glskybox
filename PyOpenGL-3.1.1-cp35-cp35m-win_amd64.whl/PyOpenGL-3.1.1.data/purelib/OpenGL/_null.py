"""Just a NULL object for reference by other modules"""
NULL = object()
